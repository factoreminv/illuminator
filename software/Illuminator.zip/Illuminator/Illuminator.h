/*
  Illuminator.h - Library for Illuminator v2 LEDboard.
  Created by Özgür Soysal, April 10, 2021.
  Released into the public domain.
*/
#ifndef Morse_h
#define Morse_h

#include "Arduino.h"

class Illuminator
{
	public:
		Illuminator();
		void beginboard();
		void setBrightness(int brightness);
		int readTemperature(bool side);
		void blink();
	private:
		int _rawtemp;
		float _temp;
};

#endif