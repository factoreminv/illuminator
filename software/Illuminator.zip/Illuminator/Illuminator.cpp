/*
  Illuminator.h - Library for Illuminator v2 LEDboard.
  Created by Özgür Soysal, April 10, 2021.
  Released into the public domain.
*/

#include "Arduino.h"
#include "Illuminator.h"

Illuminator::Illuminator()
{

}

void Illuminator::beginboard()
{
	pinMode(5, OUTPUT);
	pinMode(6, OUTPUT);
}

void Illuminator::setBrightness(int brightness)
{
	analogWrite(5, map(brightness,0,100,0,255));
	analogWrite(6, map(brightness,0,100,0,255));
}

int Illuminator::readTemperature(bool side)
{
	if (side == true){
		_rawtemp = analogRead(5);
	}
	
	else if (side == false){
		_rawtemp = analogRead(6);
	}
	
	_temp = (_rawtemp - 102.4) / 2;
	
	return _temp;
}

void Illuminator::blink()
{
	analogWrite(5, 50);
	analogWrite(6, 50);
	delay(50);
	analogWrite(5, 0);
	analogWrite(6, 0);
	delay(50);
	analogWrite(5, 50);
	analogWrite(6, 50);
	delay(50);
	analogWrite(5, 0);
	analogWrite(6, 0);
	delay(50);
	analogWrite(5, 50);
	analogWrite(6, 50);
	delay(50);
	analogWrite(5, 0);
	analogWrite(6, 0);
	delay(50);
}